Wikipedia tables published by Efthymiou et al. ISWC'17.
The original data can be downloaded from http://www.cs.toronto.edu/~oktie/webtables/csv/

select_tables/

    -- randomly selected tables used in our paper 
    
select_col_cls_GS.csv

    -- manually annotated specific classes (ground truths) of columns of selected tables
