This directory contains the original Limaye data, downloaded from http://www.cs.toronto.edu/~oktie/webtables/csv/

table_instance_json/

    -- each file contains one table
    -- values of key "contents" are table contents
    -- one arrary represent one row

Limaye_col_cls.csv
    
    -- manually annotated specific classes (ground truths) of the columns used in our paper
 